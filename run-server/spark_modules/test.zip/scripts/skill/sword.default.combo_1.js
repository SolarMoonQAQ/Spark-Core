Skill.create("spark_core:test", builder => {
    builder.addEntityAnimatableCondition()
    builder.accept(skill => {
        Logger.info("你好我是伞兵")
    })
})