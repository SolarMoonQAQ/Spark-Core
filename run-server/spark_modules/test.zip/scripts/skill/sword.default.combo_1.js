Skill.create("spark_core:test", builder => {
    builder.addEntityAnimatableCondition()
    builder.accept(skill => {
        skill.onActive(() => {
            skill.getHolder().move([0.0, 0.0, 0.1], false)
        })
    })
})